document.addEventListener('DOMContentLoaded', () => {
  let accounts = [];
  let activeTimers = [];
  let isLocked = true;
  let masterPasscode = null;
  let autoLockMinutes = 3;

  const STORAGE_SETTINGS = 'appSettings';        // Stores masterPasscode + autoLockMinutes
  const STORAGE_LAST_ACTIVITY = 'lastActivityTimestamp';

  function stopAllTimers() {
    activeTimers.forEach(id => clearTimeout(id));
    activeTimers = [];
  }

  // ====================== THEME ======================
  const body = document.body;
  const themeToggle = document.getElementById('themeToggle');

  function setTheme(isDark) {
    body.classList.toggle('dark', isDark);
    body.classList.toggle('light', !isDark);
    themeToggle.textContent = isDark ? '☀️' : '🌙';
    chrome.storage.local.set({ themeDark: isDark });
  }

  chrome.storage.local.get('themeDark', (result) => {
    setTheme(result.themeDark === true);
  });

  themeToggle.addEventListener('click', () => {
    const isDark = body.classList.contains('dark');
    setTheme(!isDark);
  });

  // ====================== STORAGE HELPERS ======================
  async function loadSettings() {
    const result = await chrome.storage.local.get([STORAGE_SETTINGS, STORAGE_LAST_ACTIVITY]);
    const settings = result[STORAGE_SETTINGS] || {};

    masterPasscode = settings.masterPasscode || null;
    autoLockMinutes = (settings.autoLockMinutes !== undefined) ? settings.autoLockMinutes : 3;

    return {
      lastActivity: result[STORAGE_LAST_ACTIVITY] || 0
    };
  }

  async function saveSettings() {
    await chrome.storage.local.set({
      [STORAGE_SETTINGS]: {
        masterPasscode: masterPasscode,
        autoLockMinutes: autoLockMinutes
      }
    });
  }

  async function updateLastActivity() {
    await chrome.storage.local.set({ [STORAGE_LAST_ACTIVITY]: Date.now() });
  }

  async function shouldBeLocked() {
    if (!masterPasscode) return false;

    const { lastActivity } = await loadSettings();
    if (!lastActivity) return true;

    const msSinceLastActivity = Date.now() - lastActivity;
    const autoLockMs = autoLockMinutes * 60 * 1000;

    return (autoLockMinutes > 0) && (msSinceLastActivity > autoLockMs);
  }

  // ====================== UI RENDERING ======================
  function renderUI() {
    stopAllTimers();
    document.getElementById('lockScreen').style.display = isLocked ? 'block' : 'none';
    document.getElementById('manualSection').style.display = (!isLocked) ? 'block' : 'none';
    document.getElementById('settingsPanel').style.display = 'none';
    document.getElementById('codesList').style.display = isLocked ? 'none' : 'block';
  }

  async function renderCodes() {
    stopAllTimers();
    const list = document.getElementById('codesList');
    list.innerHTML = '';

    const data = await chrome.storage.local.get('totpAccounts');
    accounts = data.totpAccounts || [];

    accounts.forEach((acc, index) => {
      const div = document.createElement('div');
      div.className = 'account';
      div.innerHTML = `
        <span class="account-label">${acc.label || 'Account'}</span>
        <div class="code" id="code-${index}" title="Click to copy">------</div>
        <div class="timer" id="timer-${index}"></div>
        <div class="account-controls">
          <button data-index="${index}" class="small-btn rename-btn">Rename</button>
          <button data-index="${index}" class="small-btn delete-btn">Delete</button>
          <button data-index="${index}" class="small-btn up-btn">↑ Move Up</button>
          <button data-index="${index}" class="small-btn down-btn">↓ Move Down</button>
        </div>
      `;
      list.appendChild(div);

      document.getElementById(`code-${index}`).addEventListener('click', () => copyCode(index));
      startTOTPForAccount(acc, index);
    });

    document.querySelectorAll('.delete-btn').forEach(btn => 
      btn.addEventListener('click', e => deleteAccount(parseInt(e.target.dataset.index))));
    document.querySelectorAll('.rename-btn').forEach(btn => 
      btn.addEventListener('click', e => renameAccount(parseInt(e.target.dataset.index))));
    document.querySelectorAll('.up-btn').forEach(btn => 
      btn.addEventListener('click', e => moveAccount(parseInt(e.target.dataset.index), -1)));
    document.querySelectorAll('.down-btn').forEach(btn => 
      btn.addEventListener('click', e => moveAccount(parseInt(e.target.dataset.index), 1)));
  }

  function copyCode(index) {
    const codeEl = document.getElementById(`code-${index}`);
    const code = codeEl.textContent;
    if (code && code !== '------') {
      navigator.clipboard.writeText(code).then(() => {
        const orig = codeEl.textContent;
        codeEl.textContent = 'Copied!';
        setTimeout(() => codeEl.textContent = orig, 1400);
      });
    }
  }

  function startTOTPForAccount(acc, index) {
    async function updateCode() {
      try {
        const token = await generateTOTP(acc.secret);
        const epoch = Math.floor(Date.now() / 1000);
        const expiresIn = 30 - (epoch % 30);

        const codeEl = document.getElementById(`code-${index}`);
        const timerEl = document.getElementById(`timer-${index}`);

        codeEl.textContent = token;
        timerEl.textContent = `Expires in ${expiresIn}s`;

        let color = expiresIn <= 5 ? 'var(--red)' : expiresIn <= 10 ? 'var(--orange)' : 'var(--green)';
        codeEl.style.color = color;
        timerEl.style.color = color;
      } catch (err) {
        document.getElementById(`code-${index}`).textContent = 'Error';
      }
      activeTimers.push(setTimeout(updateCode, 1000));
    }
    updateCode();
  }

  // ====================== INITIALIZATION ======================
  async function initializeApp() {
    await loadSettings();

    isLocked = await shouldBeLocked();
    renderUI();

    if (!isLocked) {
      await renderCodes();
      await updateLastActivity();
    }

    // Load saved auto-lock value into the dropdown
    const select = document.getElementById('lockTimerSelect');
    if (select) {
      select.value = autoLockMinutes.toString();
    }
  }

  // ====================== EVENT LISTENERS ======================
  // Secret input preview
  const secretInput = document.getElementById('secretInput');
  const previewEl = document.getElementById('preview');
  const validationMsg = document.getElementById('validationMsg');

  secretInput.addEventListener('input', async () => {
    let secret = secretInput.value.trim().toUpperCase().replace(/[^A-Z2-7]/g, '');

    if (secret.length === 0) {
      previewEl.textContent = '------';
      validationMsg.textContent = '';
      return;
    }

    if (secret.length < 8) {
      previewEl.textContent = '------';
      validationMsg.textContent = 'Secret too short';
      validationMsg.style.color = '#ef4444';
      return;
    }

    try {
      const token = await generateTOTP(secret);
      previewEl.textContent = token;
      validationMsg.textContent = 'Valid base32 secret ✓';
      validationMsg.style.color = '#10b981';
    } catch (e) {
      previewEl.textContent = '------';
      validationMsg.textContent = 'Invalid base32 format';
      validationMsg.style.color = '#ef4444';
    }
  });

  // Add manual account
  document.getElementById('lockIn').addEventListener('click', async () => {
    if (isLocked) return;
    let secret = secretInput.value.trim().toUpperCase().replace(/[^A-Z2-7]/g, '');
    const label = document.getElementById('labelInput').value.trim() || 'Untitled';

    if (secret.length < 8) {
      alert('Please enter a valid base32 secret key (at least 8 characters).');
      return;
    }

    accounts.push({ secret, label });
    await chrome.storage.local.set({ totpAccounts: accounts });

    secretInput.value = '';
    document.getElementById('labelInput').value = '';
    previewEl.textContent = '------';
    validationMsg.textContent = '';

    document.getElementById('manualSection').style.display = 'none';
    renderCodes();
  });

  document.getElementById('addManual').addEventListener('click', () => {
    if (isLocked) return;
    const section = document.getElementById('manualSection');
    section.style.display = (section.style.display === 'block') ? 'none' : 'block';
    if (section.style.display === 'block') secretInput.focus();
  });

  // Unlock
  document.getElementById('unlockBtn').addEventListener('click', async () => {
    const input = document.getElementById('passcodeInput').value.trim();
    const errorEl = document.getElementById('lockError');

    if (input === masterPasscode) {
      isLocked = false;
      document.getElementById('passcodeInput').value = '';
      errorEl.textContent = '';
      await updateLastActivity();
      renderUI();
      renderCodes();
    } else {
      errorEl.textContent = 'Incorrect passcode';
    }
  });

  // Settings panel toggle
  document.getElementById('settingsBtn').addEventListener('click', () => {
    const panel = document.getElementById('settingsPanel');
    panel.style.display = (panel.style.display === 'block') ? 'none' : 'block';
  });

  // Change Passcode
  document.getElementById('changePasscodeBtn').addEventListener('click', async () => {
    let oldPass = null;
    if (masterPasscode) {
      oldPass = prompt('Enter current passcode:');
      if (oldPass !== masterPasscode) {
        alert('Incorrect current passcode');
        return;
      }
    }

    const newPass1 = prompt('Enter new 4-6 digit passcode:');
    if (!newPass1 || !/^\d{4,6}$/.test(newPass1)) {
      alert('Passcode must be 4 to 6 digits.');
      return;
    }
    const newPass2 = prompt('Confirm new passcode:');
    if (newPass1 !== newPass2) {
      alert('Passcodes do not match.');
      return;
    }

    masterPasscode = newPass1;
    await saveSettings();
    alert('Passcode set/changed successfully.');
    document.getElementById('settingsPanel').style.display = 'none';
  });

  // Lock Now
  document.getElementById('lockNowBtn').addEventListener('click', async () => {
    if (!masterPasscode) {
      alert('Please set a passcode first using "Change Passcode".');
      return;
    }
    isLocked = true;
    await chrome.storage.local.set({ [STORAGE_LAST_ACTIVITY]: 0 });
    document.getElementById('settingsPanel').style.display = 'none';
    renderUI();
  });

  // Save Settings (Auto-lock timer)
  document.getElementById('saveSettingsBtn').addEventListener('click', async () => {
    autoLockMinutes = parseInt(document.getElementById('lockTimerSelect').value);
    await saveSettings();
    alert('Settings saved.');
    document.getElementById('settingsPanel').style.display = 'none';

    isLocked = await shouldBeLocked();
    renderUI();
    if (!isLocked) renderCodes();
  });

  // Account management
  async function deleteAccount(index) {
    if (!confirm('Delete this account?')) return;
    accounts.splice(index, 1);
    await chrome.storage.local.set({ totpAccounts: accounts });
    renderCodes();
  }

  async function renameAccount(index) {
    const newLabel = prompt('New account label:', accounts[index].label);
    if (newLabel === null) return;
    accounts[index].label = newLabel.trim() || 'Untitled';
    await chrome.storage.local.set({ totpAccounts: accounts });
    renderCodes();
  }

  async function moveAccount(oldIndex, direction) {
    const newIndex = oldIndex + direction;
    if (newIndex < 0 || newIndex >= accounts.length) return;

    [accounts[oldIndex], accounts[newIndex]] = [accounts[newIndex], accounts[oldIndex]];
    await chrome.storage.local.set({ totpAccounts: accounts });
    renderCodes();
  }

  // ====================== START ======================
  initializeApp();
});