async function generateTOTP(secretBase32, digits = 6, period = 30) {
    function base32Decode(str) {
      const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
      let bits = 0, value = 0, output = [];
      str = str.toUpperCase().replace(/[^A-Z2-7]/g, '');
      for (let i = 0; i < str.length; i++) {
        const idx = alphabet.indexOf(str[i]);
        if (idx === -1) continue;
        value = (value << 5) | idx;
        bits += 5;
        if (bits >= 8) {
          output.push((value >> (bits - 8)) & 0xff);
          bits -= 8;
        }
      }
      return new Uint8Array(output);
    }
  
    const keyBytes = base32Decode(secretBase32);
  
    const key = await crypto.subtle.importKey(
      'raw',
      keyBytes,
      { name: 'HMAC', hash: { name: 'SHA-1' } },
      false,
      ['sign']
    );
  
    const epoch = Math.floor(Date.now() / 1000);
    const counter = Math.floor(epoch / period);
    const counterBuffer = new ArrayBuffer(8);
    const view = new DataView(counterBuffer);
    view.setBigUint64(0, BigInt(counter), false);
  
    const hmacBuffer = await crypto.subtle.sign('HMAC', key, counterBuffer);
    const hmac = new Uint8Array(hmacBuffer);
  
    const offset = hmac[hmac.length - 1] & 0x0f;
    const binary = ((hmac[offset] & 0x7f) << 24) |
                   ((hmac[offset + 1] & 0xff) << 16) |
                   ((hmac[offset + 2] & 0xff) << 8) |
                   (hmac[offset + 3] & 0xff);
  
    const code = binary % Math.pow(10, digits);
    return code.toString().padStart(digits, '0');
  }
  
  window.generateTOTP = generateTOTP;