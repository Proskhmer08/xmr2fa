const readerDiv = document.getElementById('reader');
const status = document.getElementById('status');

const html5QrCode = new Html5Qrcode("reader");
const config = { fps: 10, qrbox: { width: 250, height: 250 } };

async function onScanSuccess(decodedText) {
  html5QrCode.stop().catch(() => {});
  status.textContent = 'QR Code scanned successfully! Processing...';

  try {
    const url = new URL(decodedText);
    const secret = url.searchParams.get('secret');
    let label = 'Imported Account';

    if (url.pathname) {
      const parts = url.pathname.split('/');
      if (parts.length > 1) label = decodeURIComponent(parts[parts.length - 1]);
    }

    if (!secret) throw new Error('No secret found');

    const result = await chrome.storage.local.get('totpAccounts');
    let accounts = result.totpAccounts || [];
    accounts.push({ secret: secret.toUpperCase(), label });
    await chrome.storage.local.set({ totpAccounts: accounts });

    status.innerHTML = `✅ Added: <strong>${label}</strong><br>Closing in 2 seconds...`;
    setTimeout(() => window.close(), 2000);
  } catch (err) {
    status.textContent = 'Error: ' + err.message;
    setTimeout(() => window.close(), 3000);
  }
}

html5QrCode.start(
  { facingMode: "environment" },
  config,
  onScanSuccess
).then(() => {
  status.textContent = 'Camera active – point at the QR code';
}).catch(err => {
  console.error(err);
  status.textContent = 'Camera error: ' + err.message + '<br>Please allow camera access when prompted.';
});